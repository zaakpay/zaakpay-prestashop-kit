<?php
/**
 * Zaakpay payment module response page
 *

 * 
 */


/* SSL Management */
//$useSSL = true;

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/Zaakpay.php');

$order_id = $_POST['orderId'];
$res_code = $_POST['responseCode'];
$res_desc = $_POST['responseDescription'];
$checksum_recv = $_POST['checksum'];
error_log("order id = {$order_id} , resp code = {$res_code} , resp desciption = {$res_desc} , checksum = {$checksum_recv}");
$obj=new Zaakpay();
$obj->setOrder($order_id,$res_code,$res_desc,$checksum_recv);

$smarty->display(dirname(__FILE__).'/response.tpl');

include(dirname(__FILE__).'/../../footer.php');	

?>
